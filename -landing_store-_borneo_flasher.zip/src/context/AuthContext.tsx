import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { loginAccount, registerAccount, type Gender } from "@/services/authService";
import { getApiErrorMessage } from "@/lib/axios";

export interface User {
  id?: number | string;
  name: string;
  email: string;
  phone?: string;
  /** Foto profil, disimpan sebagai data URL (base64). */
  avatar?: string;
}

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ ok: boolean; message?: string }>;
  register: (
    name: string,
    email: string,
    password: string,
    gender: Gender
  ) => Promise<{ ok: boolean; message?: string; needsVerification?: boolean }>;
  logout: () => void;
  updateProfile: (input: { name: string; phone?: string; avatar?: string | null }) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

const STORAGE_KEY = "bf_auth_user";
// Nama key ini HARUS sama dengan yang dibaca interceptor di src/lib/axios.ts
const TOKEN_KEY = "bf_access_token";

// Biodata (nama & no. HP) disimpan terpisah per akun supaya tetap ada
// walau user logout lalu login lagi di sesi lain.
const profileKey = (email: string) => `bf_profile:${email.trim().toLowerCase()}`;

function loadProfileOverride(email: string): { name?: string; phone?: string; avatar?: string } {
  try {
    const raw = localStorage.getItem(profileKey(email));
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveProfileOverride(email: string, data: { name: string; phone?: string; avatar?: string }) {
  localStorage.setItem(profileKey(email), JSON.stringify(data));
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setUser(JSON.parse(raw));
    } catch {
      // ignore corrupted storage
    } finally {
      setLoading(false);
    }
  }, []);

  const persist = (u: User | null, token?: string | null) => {
    setUser(u);
    if (u) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(u));
      if (token) localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(TOKEN_KEY);
    }
  };

  // Login sungguhan ke Auth/login (lihat src/services/authService.ts).
  const login: AuthContextValue["login"] = async (email, password) => {
    try {
      const res = await loginAccount({ email, password });

      // PENTING: login_post di backend membalas `status` sebagai boolean
      // (true/false), berbeda dari register_post yang pakai kode HTTP (200/400/dst).
      if (!res.status || !res.data) {
        return { ok: false, message: res.message || "Email atau password salah." };
      }

      const override = loadProfileOverride(res.data.email);
      persist(
        {
          id: res.data.id,
          name: override.name ?? res.data.full_name,
          email: res.data.email,
          phone: override.phone,
          avatar: override.avatar,
        },
        res.data.token
      );
      return { ok: true };
    } catch (err) {
      return { ok: false, message: getApiErrorMessage(err, "Gagal masuk, coba lagi.") };
    }
  };

  // Register sungguhan ke Auth/register. Backend mewajibkan verifikasi email,
  // jadi setelah sukses user BELUM otomatis login — arahkan ke halaman login.
  const register: AuthContextValue["register"] = async (name, email, password, gender) => {
    try {
      const res = await registerAccount({
        full_name: name.trim(),
        email: email.trim(),
        password,
        gender,
      });

      if (res.status !== 201) {
        return { ok: false, message: res.message || "Registrasi gagal." };
      }

      return { ok: true, message: res.message, needsVerification: true };
    } catch (err) {
      return { ok: false, message: getApiErrorMessage(err, "Gagal daftar, coba lagi.") };
    }
  };

  const logout = () => persist(null);

  const updateProfile: AuthContextValue["updateProfile"] = ({ name, phone, avatar }) => {
    if (!user) return;
    const nextAvatar = avatar === null ? undefined : avatar !== undefined ? avatar : user.avatar;
    const next: User = { ...user, name: name.trim(), phone: phone?.trim() || undefined, avatar: nextAvatar };
    saveProfileOverride(user.email, { name: next.name, phone: next.phone, avatar: next.avatar });
    persist(next);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}