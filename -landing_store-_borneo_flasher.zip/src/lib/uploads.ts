import { API_BASE_URL } from "@/lib/axios";

export const UPLOAD_BASE_URL =
  import.meta.env.VITE_UPLOAD_BASE_URL ?? "http://localhost/borneo_academy/upload/store/";

export type UploadFolder = "kategori" | "produk" | "banner";

export function resolveUploadUrl(
  filename: string | null | undefined,
  folder: UploadFolder = "kategori"
): string | null {
  if (!filename) return null;
  if (/^https?:\/\//i.test(filename)) return filename;
  return `${UPLOAD_BASE_URL}${folder}/${filename}`;
}

// URL folder upload itu sendiri, contoh:
//   http://localhost/borneo_academy/upload/store/banner/
// Dipakai untuk baca directory listing langsung (fallback kalau backend
// belum punya endpoint list JSON untuk data itu, mis. Banner/).
// TODO: setelah endpoint Banner/ di backend jadi, ganti bannerService.ts
// untuk fetch dari situ langsung (lebih stabil daripada parsing directory listing).
export function resolveUploadFolderUrl(folder: UploadFolder): string {
  return `${UPLOAD_BASE_URL}${folder}/`;
}