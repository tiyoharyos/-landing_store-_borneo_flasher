import { Icon } from "@iconify/react";
import type { Address } from "@/data/addresses";

interface Props {
  address: Address;
  /** Tampilkan tombol "Pilih" (dipakai di modal ganti alamat saat checkout) */
  selectable?: boolean;
  onSelect?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
  onMakePrimary?: () => void;
}

export default function AddressCard({
  address,
  selectable = false,
  onSelect,
  onEdit,
  onDelete,
  onMakePrimary,
}: Props) {
  return (
    <div className="address-card">
      <div className="address-card-head">
        <span className="address-card-label">
          <Icon icon="mdi:home-outline" width={14} />
          {address.label}
        </span>
        {address.isPrimary && <span className="badge badge-open">Utama</span>}
      </div>

      <p className="address-card-name">{address.recipientName}</p>
      <p className="address-card-phone">{address.phone}</p>
      <p className="address-card-text">
        {address.fullAddress}, {address.city} {address.postalCode}
      </p>

      <div className="address-card-actions">
        {onEdit && (
          <button type="button" className="address-card-link" onClick={onEdit}>
            Ubah Alamat
          </button>
        )}
        {!address.isPrimary && onMakePrimary && (
          <button type="button" className="address-card-link" onClick={onMakePrimary}>
            {selectable ? "Jadikan Utama & Pilih" : "Jadikan Alamat Utama"}
          </button>
        )}
        {onDelete && (
          <button type="button" className="address-card-link danger" onClick={onDelete}>
            Hapus
          </button>
        )}
        {selectable && onSelect && (
          <button type="button" className="ui-btn ui-btn-primary ui-btn-sm address-card-pick" onClick={onSelect}>
            Pilih
          </button>
        )}
      </div>
    </div>
  );
}
