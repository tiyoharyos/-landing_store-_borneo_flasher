import { forwardRef } from "react";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { Icon } from "@iconify/react";

export type ButtonVariant = "primary" | "outline" | "ghost" | "danger" | "subtle";
export type ButtonSize = "sm" | "md" | "lg";

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  fullWidth?: boolean;
  loading?: boolean;
  /** Iconify icon id, ditampilkan sebelum label */
  icon?: string;
  /** Iconify icon id, ditampilkan setelah label */
  iconRight?: string;
  children?: ReactNode;
}

const ICON_SIZE: Record<ButtonSize, number> = { sm: 15, md: 17, lg: 19 };

const VARIANT_CLASSES: Record<ButtonVariant, string> = {
  primary:
    "bg-brand border-brand text-white hover:bg-brand-dark hover:border-brand-dark",
  outline:
    "bg-surface border-brand text-brand hover:bg-brand-tint",
  ghost:
    "bg-transparent border-transparent text-ink-soft hover:bg-cream-deep hover:text-ink",
  subtle:
    "bg-cream-deep border-cream-deep text-ink-soft hover:bg-line",
  danger:
    "bg-warn border-warn text-white hover:brightness-90",
};

const SIZE_CLASSES: Record<ButtonSize, string> = {
  sm: "h-[34px] px-[13px] text-[12.5px] rounded-lg gap-1.5",
  md: "h-[42px] px-[18px] text-sm rounded-xl gap-2",
  lg: "h-[50px] px-6 text-[15px] rounded-xl gap-2",
};

const SPINNER_BORDER: Record<ButtonVariant, string> = {
  primary: "border-white/45 border-t-white",
  danger: "border-white/45 border-t-white",
  outline: "border-ink-soft/20 border-t-ink-soft",
  ghost: "border-ink-soft/20 border-t-ink-soft",
  subtle: "border-ink-soft/20 border-t-ink-soft",
};

const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  {
    variant = "primary",
    size = "md",
    fullWidth = false,
    loading = false,
    icon,
    iconRight,
    className = "",
    children,
    disabled,
    type = "button",
    ...rest
  },
  ref
) {
  const classes = [
    "inline-flex items-center justify-center border-[1.5px] font-semibold whitespace-nowrap select-none cursor-pointer transition-colors active:translate-y-px active:scale-[0.99] focus-visible:outline-none focus-visible:ring-[3.5px] focus-visible:ring-brand/15",
    VARIANT_CLASSES[variant],
    SIZE_CLASSES[size],
    fullWidth ? "flex w-full" : "",
    disabled || loading ? "cursor-not-allowed opacity-60" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <button ref={ref} type={type} className={classes} disabled={disabled || loading} {...rest}>
      {loading && (
        <span
          className={`w-[15px] h-[15px] rounded-full border-2 animate-spin ${SPINNER_BORDER[variant]}`}
          aria-hidden="true"
        />
      )}
      {!loading && icon && <Icon icon={icon} width={ICON_SIZE[size]} />}
      {children && <span>{children}</span>}
      {!loading && iconRight && <Icon icon={iconRight} width={ICON_SIZE[size]} />}
    </button>
  );
});

export default Button;
