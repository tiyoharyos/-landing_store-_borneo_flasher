import { motion } from "framer-motion";
import type { ReactNode } from "react";

/**
 * Animasi masuk halus (fade + slide tipis) untuk blok konten di dalam
 * sebuah halaman. Hanya transform/opacity (murah di GPU).
 *
 * - Default: animasi jalan begitu komponen mount (cocok untuk konten yang
 *   langsung terlihat di atas layar, mis. header, kartu ringkasan).
 * - `viewport`: animasi baru jalan saat elemen masuk area layar (dipakai
 *   IntersectionObserver lewat whileInView), cocok untuk konten yang
 *   letaknya di bawah lipatan (list panjang, dsb) — animasi cuma sekali.
 */
export default function FadeIn({
  children,
  delay = 0,
  y = 12,
  className = "",
  viewport = false,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
  viewport?: boolean;
}) {
  const variants = {
    hidden: { opacity: 0, y },
    show: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.35, delay, ease: [0.22, 1, 0.36, 1] as const },
    },
  };

  const viewportProps = viewport
    ? { whileInView: "show" as const, viewport: { once: true, margin: "-40px" } }
    : { animate: "show" as const };

  return (
    <motion.div className={className} initial="hidden" variants={variants} {...viewportProps}>
      {children}
    </motion.div>
  );
}
