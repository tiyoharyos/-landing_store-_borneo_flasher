import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import AuthLayout from "@/components/auth/AuthLayout";
import { useAuth } from "@/context/AuthContext";
import { Card, CardHeader, CardTitle, CardSubtitle, CardBody } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import Button from "@/components/ui/Button";
import { Form } from "@/components/ui/FormLayout";
import Swal from "sweetalert2";

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const next = params.get("next") || "/";

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [gender, setGender] = useState<"L" | "P" | "">("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!gender) {
      Swal.fire({
        icon: "warning",
        title: "Lengkapi Data",
        text: "Silakan pilih jenis kelamin terlebih dahulu.",
        confirmButtonText: "Oke",
      });
      return;
    }

    setLoading(true);
    const res = await register(name, email, password, gender);
    setLoading(false);
    if (!res.ok) {
      Swal.fire({
        icon: "error",
        title: "Gagal Daftar",
        text: res.message ?? "Registrasi gagal.",
        confirmButtonText: "Oke",
      });
      return;
    }

    // Backend mewajibkan verifikasi email, jadi user belum bisa langsung login.
    await Swal.fire({
      icon: "success",
      title: "Registrasi Berhasil",
      text: res.message ?? "Silakan cek email kamu untuk verifikasi akun sebelum login.",
      confirmButtonText: "Oke",
    });
    navigate(`/masuk${next !== "/" ? `?next=${encodeURIComponent(next)}` : ""}`);
  };

  return (
    <AuthLayout
      tagline="Belanja & Servis, Semua Ada di Sini"
      taglineSub="Daftar sekarang dan nikmati kemudahan transaksi di Borneo Flasher Store."
    >
      <Card noPadding>
        <div className="p-8">
          <CardHeader className="mb-1">
            <div>
              <CardTitle>Daftar Akun Baru</CardTitle>
              <CardSubtitle>
                Daftar akun baru untuk mulai belanja & servis di Borneo Flasher Store.
              </CardSubtitle>
            </div>
          </CardHeader>

          <CardBody>
            <Form onSubmit={handleSubmit}>
              <Input
                label="Nama Lengkap"
                icon="mdi:account-outline"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Nama kamu"
                autoComplete="name"
              />
              <Input
                label="Email"
                type="email"
                icon="mdi:email-outline"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nama@email.com"
                autoComplete="email"
              />
              <Input
                label="Password"
                type="password"
                icon="mdi:lock-outline"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Minimal 8 karakter"
                autoComplete="new-password"
              />

              <div className="flex flex-col gap-1.5">
                <span className="text-[12.5px] font-bold text-ink-soft">Jenis Kelamin</span>
                <div className="flex gap-3">
                  <label
                    className={`flex-1 flex items-center justify-center gap-2 h-11 rounded-xl border-[1.5px] cursor-pointer text-[13.75px] font-semibold transition-all ${
                      gender === "L"
                        ? "border-brand bg-brand/10 text-brand-dark"
                        : "border-line text-ink-soft"
                    }`}
                  >
                    <input
                      type="radio"
                      name="gender"
                      value="L"
                      checked={gender === "L"}
                      onChange={() => setGender("L")}
                      className="sr-only"
                    />
                    Laki-laki
                  </label>
                  <label
                    className={`flex-1 flex items-center justify-center gap-2 h-11 rounded-xl border-[1.5px] cursor-pointer text-[13.75px] font-semibold transition-all ${
                      gender === "P"
                        ? "border-brand bg-brand/10 text-brand-dark"
                        : "border-line text-ink-soft"
                    }`}
                  >
                    <input
                      type="radio"
                      name="gender"
                      value="P"
                      checked={gender === "P"}
                      onChange={() => setGender("P")}
                      className="sr-only"
                    />
                    Perempuan
                  </label>
                </div>
              </div>

              <Button type="submit" variant="primary" size="lg" fullWidth loading={loading}>
                Daftar
              </Button>
            </Form>

            <p className="text-center text-[13px] text-muted mt-1.5">
              Sudah punya akun?{" "}
              <Link to={`/masuk${next !== "/" ? `?next=${encodeURIComponent(next)}` : ""}`} className="text-brand font-bold">
                Masuk di sini
              </Link>
            </p>
          </CardBody>
        </div>
      </Card>
    </AuthLayout>
  );
}