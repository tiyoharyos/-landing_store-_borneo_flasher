import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Icon } from "@iconify/react";
import Navbar from "@/components/Navbar";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
import { formatRupiah } from "@/data/products";
import Button from "@/components/ui/Button";
import { Input, Textarea } from "@/components/ui/Input";
import { FormRow, FormSpan } from "@/components/ui/FormLayout";
import { alertWarning, toastSuccess } from "@/components/ui/alert";
import {
  createOrder,
  SHIPPING_OPTIONS,
  PAYMENT_OPTIONS,
  type ShippingMethodKey,
  type PaymentMethodKey,
} from "@/data/orders";

export default function CheckoutPage() {
  const { items, subtotal, clear } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState("");
  const [fullAddress, setFullAddress] = useState("");
  const [city, setCity] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [shippingMethod, setShippingMethod] = useState<ShippingMethodKey>("reguler");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethodKey>("transfer");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  if (items.length === 0) {
    return (
      <div>
        <Navbar />
        <div className="container text-center py-12 px-6">
          <Icon icon="mdi:cart-off" width={64} className="text-line inline-block" />
          <p className="font-display font-bold text-[1.1rem] mt-4">Keranjang Kosong</p>
          <p className="text-muted text-sm mt-1">Tambahkan produk ke keranjang sebelum checkout.</p>
          <Link to="/" className="inline-block mt-4">
            <Button variant="primary" icon="mdi:storefront-outline">
              Kembali Belanja
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const shippingCost = SHIPPING_OPTIONS.find((s) => s.key === shippingMethod)?.cost ?? 0;
  const total = subtotal + shippingCost;

  const handleSubmit = () => {
    const errors: Record<string, string> = {};
    if (!name.trim()) errors.name = "Nama penerima wajib diisi.";
    if (!phone.trim()) errors.phone = "No. HP wajib diisi.";
    if (!fullAddress.trim()) errors.fullAddress = "Alamat lengkap wajib diisi.";
    if (!city.trim()) errors.city = "Kota/kabupaten wajib diisi.";
    if (!postalCode.trim()) errors.postalCode = "Kode pos wajib diisi.";

    setFieldErrors(errors);
    if (Object.keys(errors).length > 0) {
      alertWarning({
        title: "Lengkapi Data Dulu",
        text: "Beberapa kolom alamat pengiriman masih kosong.",
      });
      return;
    }

    setSubmitting(true);
    setTimeout(() => {
      const order = createOrder(
        items,
        { name, phone, fullAddress, city, postalCode },
        shippingMethod,
        paymentMethod
      );
      clear();
      toastSuccess("Pesanan berhasil dibuat!");
      navigate(`/pesanan/sukses/${order.id}`);
    }, 700);
  };

  return (
    <div>
      <Navbar />
      <div className="container">
        <p className="font-display font-extrabold text-[1.1rem] text-ink mt-6 mb-4">Checkout</p>

        <div className="grid grid-cols-1 md:grid-cols-[1fr_320px] gap-5 pb-12 items-start">
          <div className="flex flex-col gap-4">
            <div className="bg-surface border border-line rounded-2xl p-5">
              <p className="flex items-center gap-2 font-display font-bold text-[14.5px] text-ink mb-3">
                <Icon icon="mdi:map-marker-outline" width={18} /> Alamat Pengiriman
              </p>
              <FormRow columns={2}>
                <Input
                  label="Nama Penerima"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Nama lengkap"
                  error={fieldErrors.name}
                />
                <Input
                  label="No. HP"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="08xxxxxxxxxx"
                  error={fieldErrors.phone}
                />
                <FormSpan>
                  <Textarea
                    label="Alamat Lengkap"
                    value={fullAddress}
                    onChange={(e) => setFullAddress(e.target.value)}
                    placeholder="Nama jalan, nomor rumah, RT/RW, kelurahan, kecamatan"
                    rows={3}
                    error={fieldErrors.fullAddress}
                  />
                </FormSpan>
                <Input
                  label="Kota / Kabupaten"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Contoh: Boyolali"
                  error={fieldErrors.city}
                />
                <Input
                  label="Kode Pos"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  placeholder="57316"
                  error={fieldErrors.postalCode}
                />
              </FormRow>
            </div>

            <div className="bg-surface border border-line rounded-2xl p-5">
              <p className="flex items-center gap-2 font-display font-bold text-[14.5px] text-ink mb-3">
                <Icon icon="mdi:truck-outline" width={18} /> Metode Pengiriman
              </p>
              <div className="flex flex-col gap-2">
                {SHIPPING_OPTIONS.map((opt) => (
                  <label
                    key={opt.key}
                    className={`flex items-center gap-3 border rounded-xl px-3.5 py-2.5 cursor-pointer ${
                      shippingMethod === opt.key ? "border-brand bg-brand-tint" : "border-line"
                    }`}
                  >
                    <input
                      type="radio"
                      name="shipping"
                      className="accent-brand"
                      checked={shippingMethod === opt.key}
                      onChange={() => setShippingMethod(opt.key)}
                    />
                    <div className="flex-1">
                      <p className="text-[13.5px] font-semibold text-ink">{opt.label}</p>
                      <span className="text-xs text-muted">Estimasi {opt.eta}</span>
                    </div>
                    <span className="font-mono font-bold text-[13px] text-brand-dark">{formatRupiah(opt.cost)}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="bg-surface border border-line rounded-2xl p-5">
              <p className="flex items-center gap-2 font-display font-bold text-[14.5px] text-ink mb-3">
                <Icon icon="mdi:credit-card-outline" width={18} /> Metode Pembayaran
              </p>
              <div className="flex flex-col gap-2">
                {PAYMENT_OPTIONS.map((opt) => (
                  <label
                    key={opt.key}
                    className={`flex items-center gap-3 border rounded-xl px-3.5 py-2.5 cursor-pointer ${
                      paymentMethod === opt.key ? "border-brand bg-brand-tint" : "border-line"
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      className="accent-brand"
                      checked={paymentMethod === opt.key}
                      onChange={() => setPaymentMethod(opt.key)}
                    />
                    <div className="flex-1">
                      <p className="text-[13.5px] font-semibold text-ink">{opt.label}</p>
                      <span className="text-xs text-muted">{opt.desc}</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-surface border border-line rounded-2xl p-5 sticky top-[90px]">
            <p className="font-display font-bold text-[15px] text-ink mb-3">Ringkasan Pesanan</p>
            {items.map((i) => (
              <div key={i.productId} className="flex justify-between text-[12.5px] text-muted py-1.5">
                <span>
                  {i.product.name} x{i.qty}
                </span>
                <span>{formatRupiah(i.lineTotal)}</span>
              </div>
            ))}
            <div className="h-px bg-line my-2" />
            <div className="flex justify-between text-[13.5px] text-ink-soft py-1.5">
              <span>Subtotal</span>
              <span>{formatRupiah(subtotal)}</span>
            </div>
            <div className="flex justify-between text-[13.5px] text-ink-soft py-1.5">
              <span>Ongkos Kirim</span>
              <span>{formatRupiah(shippingCost)}</span>
            </div>
            <div className="h-px bg-line my-2" />
            <div className="flex justify-between text-[15px] font-extrabold text-ink py-1.5">
              <span>Total Bayar</span>
              <span>{formatRupiah(total)}</span>
            </div>
            <Button
              variant="primary"
              size="lg"
              fullWidth
              className="mt-3"
              onClick={handleSubmit}
              loading={submitting}
            >
              Buat Pesanan
            </Button>
            <p className="text-[11.5px] text-muted mt-1.5 text-center mt-2">
              Ini adalah simulasi checkout (belum ada pembayaran nyata).
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
