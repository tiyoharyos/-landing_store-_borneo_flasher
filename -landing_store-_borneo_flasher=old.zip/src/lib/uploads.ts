import { API_BASE_URL } from "@/lib/axios";

const UPLOAD_BASE_URL =
  import.meta.env.VITE_UPLOAD_BASE_URL ?? `${API_BASE_URL.replace(/\/?$/, "")}/upload/store/`;

export function resolveUploadUrl(
  filename: string | null | undefined,
  folder: "kategori" | "produk" = "kategori"
): string | null {
  if (!filename) return null;
  if (/^https?:\/\//i.test(filename)) return filename;
  return `${UPLOAD_BASE_URL}${folder}/${filename}`;
}
